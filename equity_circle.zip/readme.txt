1. composer udpate
2. rename to .env.example to .env and set db name, username, pass 
3. php artisan migrate
4. php artisan db:seed
 login email: admin@example.com 
 password: password 
 